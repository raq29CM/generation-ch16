package MiSaludo;

public class Saludo {
    String textoS = "Hola Mundo Java oop";
    int a = 3;
    public void saludar(){
        System.out.println("Hola Java OOP");
    }
    public String saludar0(){
        return textoS;
    }
}
