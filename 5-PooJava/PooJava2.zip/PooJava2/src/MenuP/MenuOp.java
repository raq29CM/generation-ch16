package MenuP;

public class MenuOp {

    public void menu(){
        System.out.println("1.- Saludo ");
        System.out.println("2.- Mi ejemplo Java ");
        System.out.println("3.- Mi Fecha ");
        System.out.println("4.- Ejemplo Resumen ");
        System.out.println("5.- Default ");
    }
}
