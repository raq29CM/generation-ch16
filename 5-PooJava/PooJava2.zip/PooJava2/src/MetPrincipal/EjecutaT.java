package MetPrincipal;

import LlamadasSys.EnlaceSys;

public class EjecutaT {
    public static void main(String[] args) {
        EnlaceSys es = new EnlaceSys();
        es.enlazar();
    }
}
